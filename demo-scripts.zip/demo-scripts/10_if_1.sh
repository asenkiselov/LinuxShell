#!/bin/bash

if [ "$(whoami)" != 'root' ]; then
        echo "You have no permission to run $0 as non-root user."
        exit 1;
fi

echo -n "Enter str1: "
read str1
echo -n "Enter str2: "
read str2
echo -n "Enter file: "
read file
echo -n "Enter num1: "
read num1

if [ $str1 == $str2 ]; then  # ';' се използва за да може then да е на същия ред
  echo "$str1 = $str2"
else
  echo "str1 and str2 are not equal"
fi

if [ -f $file ]; then # пример с файлове
  ls -l $file
else
  echo "File $file does not exist"
fi 

if [ $num1 -eq 10 ]; then
  echo "num1 = 10"
elif [ $num1 -gt 100 ]; then
  echo "num1 > 100"
else 
  echo "You entered: $num1" 
fi
