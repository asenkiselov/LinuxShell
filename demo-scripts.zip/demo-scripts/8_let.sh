#!/bin/bash

echo -n "Enter the first number: "
read var1
echo -n "Enter the second: "
read var2
declare -i var3

echo ----------
echo "$var1 + $var2 = $(( $var1+$var2 ))" # тук използваме двойни скоби, както виждате трябва да сложим $ пред
            # израза, за да се изчисли
let res=$var1*var2
echo "$var1 * $var2 = $res"
var3=100
var3=$var3+10
echo "$var3" # тъй като тази променлива е декларирана като integer не е нужно да използваме командата let

