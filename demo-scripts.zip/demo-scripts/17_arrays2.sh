#!/bin/bash

declare -a array # декларираме масив с declare

echo -n "Enter some numbers separated by space: "
read -a array # присвояваме въведените числа на елементите на масива (забележете опцията на read '-a')

elements=${#array[@]} # тук присвояваме на променливата elements броя елементи на масива

# ${array[@]} съдържа елементите на масива поотделно. Можете да го използвате за цикъл for-in
# например:
for i in ${array[@]}; do
   echo $i
done

# сега ще покажем елементите на масива с цикъл while

i=0

while [ $i -lt $elements ]; do
  echo $i : ${array[$i]}
  let "i = $i + 1"
done

echo "bye"

