#!/bin/bash

var1=10
var2="m000"
[ $var1 -eq 10 ]
echo $?
[ $var2 = "me0w" ]
echo $?
