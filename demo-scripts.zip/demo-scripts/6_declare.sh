#!/bin/bash

declare -i var # декларираме променлива от тип integer
var=100
echo $var
declare -r var2=123.456 # декларираме readonly променлива
echo $var2
var2=121.343 # опитваме се да променим стойността на var2
echo $var2   # стойността на var2 ще е все още 123.456
