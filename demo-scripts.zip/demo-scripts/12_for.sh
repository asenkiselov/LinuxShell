#!/bin/bash
# specific conversion script for my html files to php
LIST="$(ls *.html)"
for infile in $LIST; do
     outfile=$(ls "$infile" | sed -e 's/html/php/')
     cp $infile $outfile
done
