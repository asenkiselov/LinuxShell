#!/bin/bash
echo The value of var is $var
echo child end
