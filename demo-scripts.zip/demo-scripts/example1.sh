#!/bin/bash
set -x

ts2date() {
 echo `date -d @$(  echo "($1 + 500) / 1000" | bc)`
}

user=root
password=P@ssp0rt
currenttimems=`date +%s`000
yesterday=`echo "$currenttimems - 86400000" | bc`

while read -a row
do
    date1=`ts2date "${row[0]}"`
    echo "$date1 | ${row[1]} | ${row[2]}"
done < <(echo "select created,num,handled from call_stat where handled=0 and created > $yesterday order by created desc" | mysql --user=$user --password=$password aossia_appspace_cc) > result.log

ydate=`ts2date $yesterday`
cat ./result.log | mail -s "Real abandoned calls for $ydate" dimitar.dimitrov@aossia.com
cat ./result.log | mail -s "Real abandoned calls for $ydate" mariana.ivanova@cityclinic.bg
cat ./result.log | mail -s "Real abandoned calls for $ydate" martin.katsarski@cityclinic.bg
