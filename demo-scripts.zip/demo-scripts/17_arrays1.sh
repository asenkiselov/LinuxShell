#!/bin/bash

array[1]=m00
array[34]=me0w
array[40]=123

echo "array[1] = ${array[1]}"
echo "array[34] = ${array[34]}"
echo "array[40] = ${array[40]}"
