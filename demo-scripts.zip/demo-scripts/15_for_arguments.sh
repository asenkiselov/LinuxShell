#!/bin/bash

for m00 in $@
do	
  echo $m00
done
