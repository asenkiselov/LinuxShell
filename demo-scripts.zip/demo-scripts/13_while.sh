#!/bin/bash

m00=yes

while [ $m00 == "yes" ]; do
  echo -n "Enter a string: "
  read str1
  echo "You entered: $str1"
  echo -n "Do you want to continue? "
  read m00
done
