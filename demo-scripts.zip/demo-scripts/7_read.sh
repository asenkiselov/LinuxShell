#!/bin/bash
echo -n "Enter a string: "
read str
echo "String you entered: $str"
