#!/bin/bash
lssrc='ls /tmp'
$lssrc
