#!/bin/bash

names="Ivan Koljo Asen Sasho Misho"

for name in $names; do
  echo $name
done | sort > names
