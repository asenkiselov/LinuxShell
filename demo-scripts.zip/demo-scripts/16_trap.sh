#!/bin/bash

trap 'echo "Bye"; exit 1' 2

echo "Enter a string: "
read m00
echo "nah"
