#!/bin/bash
export var=100
./5_export_child.sh
echo parent end
