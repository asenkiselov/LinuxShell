#!/bin/bash
maxCpu=90
count=0
countMax=5

logger "start fix cpu script"

function restartProcess {
 logger "Restart Linksync due to high CPU load"
 /opt/sftpd/restart
}

while true;do
 cpuUsage=`vmstat 1 2 > vmstat.log && cat vmstat.log | tail -1 | awk '{ print 100-$15 }'`
 if [ $cpuUsage -ge $maxCpu ];then
  ((count++))
 fi
 if [ $count -gt $countMax ];then
  restartProcess
  count=0
 fi
 sleep 1
done

