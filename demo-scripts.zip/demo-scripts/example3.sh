#!/bin/sh
 
if [ $# -ne 2 ];then
  echo "Usage $0 <DEFAULT> <BACKUP>"
  exit 1
fi
 
echo $1 > /var/log/default_gw_current
echo $2 > /var/log/backup_gw_current
echo $1 > /var/log/default_gw_best
 
while true;do
ping -c5 `cat /var/log/default_gw_best` 1>> /var/log/rtr.log
if [ $? -eq 0 ] && [ `cat /var/log/default_gw_current` != `cat /var/log/default_gw_best` ];then
 route del default gw `cat /var/log/default_gw_current`
 route add default gw `cat /var/log/default_gw_best`
 cat /var/log/default_gw_current > /tmp/gw_def_tmp
 cat /var/log/default_gw_best > /var/log/default_gw_current
 cat /tmp/gw_def_tmp > /var/log/backup_gw_current
fi
 
echo $$ > /var/run/rtr.pid
ping -c5 `cat /var/log/default_gw_current` 1>> /var/log/rtr.log

if [ $? -ne 0 ];then
 cat /var/log/default_gw_current > /tmp/gw_def_tmp
 route del default gw `cat /var/log/default_gw_current`
 route add default gw `cat /var/log/backup_gw_current`
 cat /var/log/backup_gw_current > /var/log/default_gw_current
 cat /tmp/gw_def_tmp > /var/log/backup_gw_current
 echo The default route is changed. The current default route is `cat /var/log/default_gw_current` | mail -s "Changed default gateway" root
fi

if [ ! -f /var/run/rtr.pid ];then
 exit 1
fi

done
